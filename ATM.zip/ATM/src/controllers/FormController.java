package controllers;


import beans.Atm;

import java.util.List;

import javax.annotation.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

import java.io.Serializable;

@Named("formController")
@ViewScoped
public class FormController implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void onSubmit(Atm atm) {
		//Forward to Test Response View along with the User Managed Bean
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("atm", atm);
		atm.printChange();
	}
	
}
