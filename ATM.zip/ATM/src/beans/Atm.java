package beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@ManagedBean
@ViewScoped
public class Atm {
	public double amount = 438.89;
	
	//The amount split into bills and change
	//bills
	public int hundreds = 0;
	public int fifties = 0;
	public int twenties = 0;
	public int tens = 0;
	public int fives = 0; 
	public int ones = 0 ;
	//coins
    public int quarters = 0;
    public int dimes = 0;
    public int nickels = 0;
    public int pennies = 0;
	
    public Atm() {
        this.amount = 434.79;
    }
    public Atm(int amount) {
        this.amount = amount;
    }
    
    public void printChange() {
    	//Calculating the bills
    	calcChange();
    	
    	//printing everything out
    	//System.out.println(hundreds);
    	System.out.printf("Hundreds(%d), Fifties(%d), Twenties(%d), Tens(%d), Fives(%d), Ones(%d),"
    			+ " Quarters(%d), Dimes(%d), Nickels(%d), Pennies(%d)", hundreds, fifties, twenties, tens, fives, ones, quarters, dimes, nickels, pennies);
    }
    
    public void calcChange() {
    	//bills
    	hundreds();
    	fifties();
    	twenties();
    	tens();
    	fives();
    	ones();
    	//coins
    	quarters();
    	dimes();
    	nickels();
    	pennies();
    }
    
	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
    
	//These are the functions to get the amount of each bill
	public void hundreds() {
		hundreds = (int) (amount/100);
		amount = amount%100;
	}
	public void fifties() {
		fifties = (int) (amount/50);
		amount = amount%50;
	}
	public void twenties() {
		twenties = (int) (amount/20);
		amount = amount%20;
	}
	public void tens() {
		tens = (int) (amount/10);
		amount = amount%10;
	}
	public void fives() {
		fives = (int) (amount/5);
		amount = amount%5;
	}
	public void ones() {
		ones = (int) (amount/1);
		amount = amount%1;
	}
	public void quarters() {
		quarters = (int) (amount/.25);
		amount = amount%.25;
	}
	public void dimes() {
		dimes = (int) (amount/.10);
		amount = amount%.10;
	}
	public void nickels() {
		nickels = (int) (amount/.05);
		amount = amount%100;
	}
	public void pennies() {
		pennies = (int) (amount/.01);
	}
    

}